//programa que muestra los números del 1 al 10                                                             

package ud2.ejemplos;

public class Ejemplo1For {

    public static void main(String[] args) {
        //for (int i = 1; i <= 10; i++) {    //inicio del for SUMA
        
        for (int i = 10; i > 1; i--) {    //inicio del for RESTA
            System.out.print(i + " ");
        }  //fin del for
        System.out.println("\nFin programa");  
   

    
    // EQUIVALENTE CON WHILE 
       /* 
        int i =1 ; 
         while (i <=10) {
            System.out.println(i + " ");
            i++;
            }
        */
    }

}

