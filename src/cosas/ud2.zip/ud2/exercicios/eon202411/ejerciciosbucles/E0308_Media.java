package ud2.exercicios.eon202411.ejerciciosbucles;

import java.util.*;

public class E0308_Media {
    public static void main(String[] args) {
        final int TOTALNUMEROS = 10 ; 
        Scanner sc = new Scanner(System.in);
        int n1, n2, n3, n4, n5, n6, n7, n8, n9, n10;

        System.out.println("Introduce los 10 numeros: ");
        
        int contador = 0;

        while (contador < 10) {
            
        }

        n1 = sc.nextInt();
        n2 = sc.nextInt();
        n3 = sc.nextInt();
        n4 = sc.nextInt();
        n5 = sc.nextInt();
        n6 = sc.nextInt();
        n7 = sc.nextInt();
        n8 = sc.nextInt();
        n9 = sc.nextInt();
        n10 = sc.nextInt();
        sc.close(); 
        int mediaNumeros = (n1+n2+n3+n4+n5+n6+n7+n8+n9+n10)/TOTALNUMEROS;

        System.out.println(mediaNumeros);

       //*  while {
        //    System.out.println("La media es " + mediaNumeros);
        //    }
        //while (TOTALNUMEROS = true); */
        




        
        
    }
    
}
