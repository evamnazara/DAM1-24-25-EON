/* Potencia. Escribe un programa que calcule la potencia de un número elevado a otro utilizando recursividad.
 */

package ud2.exercicios.eon202411.ejerciciosrecursividad;

public class Potencia {

    public static void main(String[] args) {
        
    }
    
}
