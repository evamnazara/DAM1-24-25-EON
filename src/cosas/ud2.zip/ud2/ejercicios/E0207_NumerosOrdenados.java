package ud2.ejercicios;
import java.util.*;

public class E0207_NumerosOrdenados {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("numero 1");
        int num1 = sc.nextInt();

        System.out.println("numero 1");
        int num2 = sc.nextInt();

        System.out.println("numero 1");
        int num3 = sc.nextInt();
        
        if (num1 > num2 && num1 > num3) {
            System.out.println("El orden es " + num1 + ", " + num2 + ", " + num3 );
            
        } else {

        }
        sc.close();
        
        

    }
    
}
