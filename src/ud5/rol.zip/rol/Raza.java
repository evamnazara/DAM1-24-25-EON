package ud5.rol;

public enum Raza {
    HUMANO, ELFO, ENANO, HOBBIT, ORCO, TROLL
}
