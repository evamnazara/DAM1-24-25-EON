package tests;

//import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class PruebasTest {
    @Test
    void testEsNumeroPerfecto(int n) {

    }

}
